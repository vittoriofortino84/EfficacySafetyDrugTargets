setwd('~/Documents')


### Importing efficacy score

tissue_score<-read.table('tissue_score.txt',stringsAsFactors=F)
tissue_score<-setNames(tissue_score$V2,tissue_score$V1)

modul_score<-read.table('modul_score.txt',stringsAsFactors=F)
modul_score<-setNames(modul_score$V2,modul_score$V1)

library(data.table)

df<-fread('opentargets_score.csv',stringsAsFactors=F,sep=',',data.table=F)

opt.score<-as.matrix(df[,-1])
rownames(opt.score)<-df[,1]


### Importing safety scores

ADR_score<-read.table('ADR_score.txt',stringsAsFactors=F)
ADR_score<-setNames(ADR_score$V2,ADR_score$V1)

centrality_score<-read.table('centrality_score.txt',stringsAsFactors=F)
centrality_score<-setNames(centrality_score$V2,centrality_score$V1)

onco_score<-read.table('onco_score.txt',stringsAsFactors=F)
onco_score<-setNames(onco_score$V2,onco_score$V1)


### Computing overall safety score

safety_scores<-list(ADR=ADR_score,centrality=centrality_score,onco=onco_score)

all_genes<-Reduce('union',sapply(safety_scores,names))

mat_scores<-matrix(0,nrow=length(all_genes),ncol=length(safety_scores),
                   dimnames=list(all_genes,names(safety_scores)))

for(i in names(safety_scores)){
  mat_scores[names(safety_scores[[i]]),i]<-safety_scores[[i]]
}

library(scales)

safety_scores[['overall']]<-apply(mat_scores,1,function(x)sum(sort(x,decreasing=T)/(c(1:3)^2)))
safety_scores[['overall']]<-rescale(safety_scores[['overall']],to=c(0,1))


### Compiling overall dataset

all_ass.<-Reduce('union',list(colnames(opt.score),names(tissue_score),names(modul_score)))

db<-as.data.frame(matrix(NA,nrow=length(all_ass.),ncol=10))
rownames(db)<-all_ass.

db[colnames(opt.score),1:7]<-t(opt.score[1:7,])

db[colnames(opt.score),8]<-opt.score[26,]

db[names(modul_score),9]<-modul_score

db[names(tissue_score),10]<-tissue_score

db<-data.frame(matrix(unlist(strsplit(rownames(db),'-')),byrow=T,ncol=2),db,stringsAsFactors=F)
rownames(db)<-NULL

db<-merge(db,safety_scores$ADR,by.x=1,by.y=0,all=T,sort=F)

db<-merge(db,safety_scores$centrality,by.x=1,by.y=0,all=T,sort=F)

db<-merge(db,safety_scores$onco,by.x=1,by.y=0,all=T,sort=F)

db<-merge(db,safety_scores$overall,by.x=1,by.y=0,all=T,sort=F)

colnames(db)<-c('gene_id','disease_id',rownames(opt.score)[1:7],'open_targets','modulation',
                'tissue_specific','safety_ADR','safety_centrality','safety_onco','safety_overall')


### Selecting case study diseases

set_dis<-c("EFO_0001360",'EFO_0000249')

db_sel<-lapply(set_dis,function(x)db[db[,2]%in%x,c(1,2,10:12,16)])


### Retrieving top-50 targets for selected diseases by combining efficacy and safety scores

scatter_coord<-function(mat){
  
  integration<-apply(mat[,3:5],1,function(x)max(na.omit(x)))
  
  safety_integration<-(integration+(1-mat[,6]))/2
  
  ind<-order(safety_integration,decreasing=T)
  
  return(data.frame(gene_id=mat[ind,1][1:50],efficacy=integration[ind][1:50], safety=(1-mat[ind,6])[1:50]))
}

e.s<-lapply(db_sel,scatter_coord)
names(e.s)<-c("type II diabetes mellitus",'Alzheimer\'s disease')

library(org.Hs.eg.db)

symb<-lapply(e.s,function(x)
  select(org.Hs.eg.db, keys=as.character(x$gene_id),columns="SYMBOL",keytype="ENSEMBL"))

e.s<-mapply(function(x,y)merge(y,x,by.y='gene_id',by.x='ENSEMBL',all.y=T,sort=F),e.s,symb,SIMPLIFY=F)


### Retrieving top-50 targets for selected diseases according to OT platform

T2DM<-read.csv('targets_associated_with_type_II_diabetes_mellitus.csv',stringsAsFactors = F)[1:50,c(2,1,3)]
T2DM<-cbind(T2DM,1-safety_scores$overall[T2DM$target.id])

AD<-read.csv('targets_associated_with_Alzheimer\'s_disease.csv',stringsAsFactors = F)[1:50,c(2,1,3)]
AD<-cbind(AD,1-safety_scores$overall[AD$target.id])

colnames(AD)<-colnames(T2DM)<-colnames(e.s$`type II diabetes mellitus`)

OT<-list(T2DM,AD)

names(OT)<-names(e.s)


### Generating .xlsx files

v<-mapply(list,e.s,OT,SIMPLIFY=F)

library(xlsx)

for(i in names(v)){
  write.xlsx2(x=v[[i]][[1]],file=paste(i,'.xlsx',sep=''),
                sheetName='efficacy+safety',col.names=T,row.names=F)
    
  write.xlsx2(x=v[[i]][[2]],file=paste(i,'.xlsx',sep=''),
              sheetName='OT',col.names=T,row.names=F,append=T)
}


### Defining list of golden standards

withdrawn<-unlist(read.table('withdrawn.txt',stringsAsFactors=F),use.names=F)

without_result<-unlist(read.table('clinical_trials_without_result.txt',stringsAsFactors=F),use.names=F)

G.S<-unlist(read.table('G.S.txt',stringsAsFactors=F),use.names=F)

is_cancer<-read.table('is_cancer.txt',sep='\t',header=F)

essential<-read.csv('Homo sapiens_consolidated.csv',stringsAsFactors=F)

gs_split<-matrix(unlist(strsplit(G.S,'-')),byrow=T,ncol=2)

cancer_target<-unique(gs_split[gs_split[,2]%in%is_cancer[,1][is_cancer[,2]=='YES'],1])

true_positive<-setdiff(setdiff(gs_split[,1],cancer_target),withdrawn)

essential<-essential$locus[essential$essentiality.consensus=='Essential']

gs_l<-list(withdrawn,cancer_target,essential,without_result,true_positive)
names(gs_l)<-c('withdrawn_drug_targets','cancer_targets','essential_genes',
               'failed_trial_targets','control')


### Adding gene status (dangerous/unspecified)

library(reshape2)
v<-lapply(v,function(x)melt(x,id.vars=c('ENSEMBL','SYMBOL','efficacy','safety')))

add_status<-function(x,gs_list){
  x[,'status']<-'unspecified'
  x[x[,1]%in%Reduce(union,gs_l[1:4]),'status']<-'potentially dangerous targets'
  x
}

v<-lapply(v,add_status,gs_list=gs_l)


### Generating final scatter plots

v[[1]]<-v[[1]][!v[[1]]$SYMBOL%in%c("MIR222","MIR155"),]

sel<-c('FFAR4','KDM1B','KDM3A','TWIST2','RBP2','S1PR3')

v<-lapply(v,function(x){x[['SYMBOL2']]<-x$SYMBOL;
x$SYMBOL2[!x$SYMBOL2%in%sel]<-'';x})


library(RColorBrewer)
col_pal=brewer.pal(3,'Greys')[2:3]

col_stat<-c('darkred',"grey25")
names(col_stat)<-c('potentially dangerous targets','unspecified')

library(ggrepel)

pdf('case_study.pdf',6,6)
for(i in names(v)){
  print(
    ggplot(v[[i]],aes(x=safety,y=efficacy,color=as.factor(v[[i]]$status),shape=as.factor(v[[i]]$L1)))+
      geom_point(size=6,alpha=0.7,stroke=0)+xlab('safety')+ylab('efficacy')+
      scale_shape_manual(values = c(19,17),labels=c('efficacy+safety','OT'))+
      scale_color_manual(values=col_stat[levels(as.factor(v[[i]]$status))],labels=c('','potentially dangerous targets'))+
      theme(legend.title=element_blank(),plot.title=element_text(size=rel(1.5),family='sans',hjust=0.5),
            legend.position = 'bottom',legend.box = 'horizontal',legend.key = element_blank(),axis.title=element_text(size=18,family='sans'),
            axis.text=element_text(size=18,family='sans'),legend.text = element_text(size=14,family='sans'),
            panel.background=element_rect(fill = 'transparent'),panel.grid.minor=element_line(color = 'lightgrey'))+ ylim(0.5,1)+
      guides(colour=guide_legend(override.aes = list(shape=c(19,17),colour=rep('darkred',2))))+
      geom_label_repel(aes(label=SYMBOL2,family='sans'),show.legend=F,segment.size=0.7,size=5,segment.alpha=1,box.padding = unit(0.65,'lines'),
                       point.padding = unit(0.6,'lines'),fill='white')
  )
}
dev.off()