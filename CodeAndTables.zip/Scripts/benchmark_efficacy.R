setwd('~/Documents')

### Importing in the order: golden standard associations, tissue_specific, modulation and OT scores

G.S<-unlist(read.table('G.S.txt',stringsAsFactors=F),use.names=F)

tissue_score<-read.table('tissue_score.txt',stringsAsFactors=F)
tissue_score<-setNames(tissue_score$V2,tissue_score$V1)

modul_score<-read.table('modul_score.txt',stringsAsFactors=F)
modul_score<-setNames(modul_score$V2,modul_score$V1)

library(data.table)

df<-fread('opentargets_score.csv',stringsAsFactors=F,sep=',',data.table=F)

opt.score<-as.matrix(df[,-1])
rownames(opt.score)<-df[,1]


### Assessing positive predictive values

ppvpercents<- function(n,ind) {
  nconn <- n
  ppv <- vector ()
  iters <- seq (1, 100,1)
  for (i in 1:length(iters)){
    perc <- round(nconn/100 * iters[i])
    ppv[[i]]<- sum(ind<perc)/perc/(length(ind)/nconn)
  }
  return(list(x=iters,y=ppv))
}


datatype_score<-apply(opt.score[1:6,],1,function(x)
  {i<-x!=0;new_x<-x[i];names(new_x)<-colnames(opt.score)[i];new_x})

l<-datatype_score
l[['tissue_specific']]<-tissue_score
l[['modulation']]<-modul_score


ind<-lapply(l,function(x)order(x,decreasing=T))
ppv<-lapply(l,function(x)names(x)%in%G.S)


ppvperc<-mapply(function(i,x)ppvpercents(length(i),which(x[i])),ind,ppv,SIMPLIFY=F)


### Recomputing OT overall score and compiling efficacy dataset

all_ass.<-Reduce('union',list(colnames(opt.score),names(tissue_score),names(modul_score)))

db<-as.data.frame(matrix(NA,nrow=length(all_ass.),ncol=4))
rownames(db)<-all_ass.

data_s.<-c("eva","uniprot_literature","gene2phenotype","gwas_catalog","cancer_gene_census","eva_somatic",
           "intogen","expression_atlas","phenodigm","reactome","europepmc")

db[colnames(opt.score),1]<-apply(opt.score[data_s.,],2,function(x)
  sum(sort(x*c(rep(1,7),0.5,0.2,1,0.2),decreasing=T)/(c(1:11)^2)))

library(scales)

db[colnames(opt.score),1]<-rescale(db[colnames(opt.score),1],to=c(0,1))

db[colnames(opt.score),2]<-apply(opt.score[1:6,],2,max)

db[names(tissue_score),3]<-tissue_score

db[names(modul_score),4]<-modul_score

colnames(db)<-c('open_targets(HS)','open_targets(max)','tissue_specific','modulation')


### Integrating each proposed efficacy score with OT

single_integration<-function(d=db,score_name){
  
  d_split<-matrix(unlist(strsplit(rownames(d),'-')),byrow=T,ncol=2)
  
  logi<-as.data.frame(apply(d,2,function(x)!is.na(x)))
  
  idx<-which(colnames(d)%in%score_name)
  
  dis_set<-Reduce(intersect,lapply(logi[c(1,idx)],function(i)d_split[i,2]))
  
  dis_logi<-d_split[,2]%in%dis_set
  
  opt_idx<-logi[[1]]&dis_logi
  ass_idx<-(logi[[1]]|logi[[idx]])& dis_logi
  
  O.T_HS<-d[opt_idx,1];names(O.T_HS)<-rownames(d)[opt_idx]
  O.T_max<-d[opt_idx,2];names(O.T_max)<-rownames(d)[opt_idx]
  
  integr_HS<-apply(d[opt_idx,c(1,idx)],1,function(x)max(na.omit(x)))
  integr_max<-apply(d[opt_idx,c(2,idx)],1,function(x)max(na.omit(x)))
  
  integr_HS_all<-apply(d[ass_idx,c(1,idx)],1,function(x)max(na.omit(x)))
  integr_max_all<-apply(d[ass_idx,c(2,idx)],1,function(x)max(na.omit(x)))
  
  l_score<-list(O.T_HS,O.T_max,integr_HS,integr_max,integr_HS_all,integr_max_all)
  
  names(l_score)<-c('OT[hs]','OT[max]','E[hs](OT associations)',
                    'E[max](OT associations)','E[hs](OText. associations)',
                    'E[max](OText. associations)')
  
  l_score
}

modul_integration<-single_integration(score_name='modulation')
tissue_integration<-single_integration(score_name='tissue_specific')


### Assessing true positive rate means and confidence intervals (CI)

define_mean_and_ci<-function(gs,l,nm){
  
  true_ass.<-intersect(gs,names(l[[1]]))
  
  set.seed(123)
  gs_boot<-lapply(1:100,sample,x=true_ass.,size=round(length(true_ass.)*0.8))
  
  l_sort<-lapply(l,sort,decreasing=T)
  
  sapply(l_sort,function(x)x[1:length(l_sort[[1]])])
  
  mat_list<-list()
  perc<-c(1,c(1:2)*5)
  
  for(i in 1:length(gs_boot)){
    mat_perc<-matrix(0,nrow=length(l_sort),ncol=3,dimnames=list(names(l_sort),paste(perc,'%',sep='')))  
    for(j in 1:ncol(mat_perc)){
      for(k in 1:nrow(mat_perc)){
        score_perc<-l_sort[[k]][1:round((length(l_sort[[k]])*perc[j])/100)]
        mat_perc[k,j]<-round((sum(names(score_perc)%in%gs_boot[[i]])/length(gs_boot[[i]]))*100,1)
      }
    }
    mat_list[[i]]<-mat_perc
  }
  
  m<-melt(mat_list)
  m[,1]<-as.character(m[,1])
  m[,2]<-as.character(m[,2])
  
  d<-sapply(unique(m$Var2),function(i)melt(sapply(unique(m$Var1),function(j)
    m$value[m$Var2==i&m$Var1==j],simplify = F)),simplify = F)
  
  d.lm<-lapply(d,function(x)lm(value~L1,data=x))
  d.aov<-lapply(d.lm,aov)
  
  tuckey.test<-lapply(d.aov,TukeyHSD)
  
  mat_mean<-lapply(d,function(x)aggregate(x$value,list(x$L1),mean))
  CI<-lapply(d,function(x)aggregate(x$value,list(x$L1),quantile,probs=c(0.25,0.975)))
  
  
  tuckey.missing<-lapply(tuckey.test,function(x){y<-do.call(rbind,strsplit(rownames(x$L1),'-'));
                                     x$L1[,1:3]<-round(x$L1[,1:3],3);
                                     y<-cbind(y,x$L1);colnames(y)[1:2]<-c('grp1','grp2');y})
  
  tuckey.missing<-mapply(function(x,y)merge(x,y,by.x='grp1',by.y='Group.1'),
                         tuckey.missing,mat_mean,SIMPLIFY=F)
  
  tuckey.missing<-mapply(function(x,y)merge(x,y,by.x='grp2',by.y='Group.1'),
                         tuckey.missing,mat_mean,SIMPLIFY=F)
  
  tuckey.missing<-lapply(tuckey.missing,function(x){x<-x[,c(2:1,7:8,3:6)];
                                        colnames(x)[3:4]<-c('mean1','mean2');x})
  
  for(i in names(d.aov)){
    sink(file=paste('Test/anova_',nm,'_',i,'.txt',sep=''))
    summary(d.aov[[i]])
    sink()
    write.table(tuckey.missing[[i]],file=paste('Test/tuckey_',nm,'_',i,'.txt',sep=''),
                sep='\t',quote=F,row.names =F,col.names =T)
  }
  
  mat_mean<-do.call(cbind,lapply(mat_mean,function(x)setNames(round(x$x,1),x$Group.1)))
  
  CI_inf<-do.call(cbind,lapply(CI,function(x)setNames(round(x$x[,1],1),x$Group.1)))
  CI_sup<-do.call(cbind,lapply(CI,function(x)setNames(round(x$x[,2],1),x$Group.1)))
  
  res<-list(mat_mean[c(5,1:2,6,3:4),],CI_inf[c(5,1:2,6,3:4),],CI_sup[c(5,1:2,6,3:4),])
  names(res)<-c('mean','CI_inf','CI_sup');res 
  
}

modul_mean_and_ci<-define_mean_and_ci(gs=G.S,l=modul_integration,nm='modulation')
tissue_mean_and_ci<-define_mean_and_ci(gs=G.S,l=tissue_integration,nm='tissue_specific')


### Generating plot of positive predictive values (lineplots) for OT data-type scores

pdf('OT_ppvs.pdf',5,5)

library(RColorBrewer)

col_pal=brewer.pal(8,'Dark2')

plot(ppvperc[[1]]$x,ppvperc[[1]]$y,type='l',col=col_pal[[1]],xlab='Percentile(%)',ylab='Normalized PPV',
     ylim=c(0,16),lwd=3,xlim=c(0,50),panel.first=abline(h=seq(2.5,15,by=2.5),v=seq(0,50,by=5),lwd=2,lty=3,col="lightgray"),
     cex=1.1)
for(i in 2:6){
  lines(ppvperc[[i]]$x,ppvperc[[i]]$y,type='l',col=col_pal[i],lwd=3,lty=c(rep(1,6),2,2)[i])
}
abline(1,0,col='black',lty=2,lwd=2)
legend('topright',fill = col_pal,legend = gsub('_',' ',names(ppvperc)[1:6]),bty = 'n',cex=1.1)

dev.off()


### Generating plot of positive predictive values (lineplots) for proposed efficacy scores

pdf('efficacy_ppv.pdf',5,5)

col_pal=brewer.pal(8,'Dark2')

plot(ppvperc[[4]]$x,ppvperc[[4]]$y,type='l',col=col_pal[[4]],xlab='Percentile(%)',ylab='Normalized PPV',
     ylim=c(0,6),lwd=3,xlim=c(0,50),panel.first=abline(h=1:6,v=seq(0,50,by=5),lwd=2,lty=3,col="lightgray"),
     cex=1.1)
for(i in 7:8){
  lines(ppvperc[[i]]$x,ppvperc[[i]]$y,type='l',col=col_pal[i],lwd=3,lty=1)
}
abline(1,0,col='black',lty=2,lwd=2)
legend('topright',fill=col_pal[c(4,7:8)],legend=c('rna expression','tissue-specific','modulation'),bty = 'n',cex=1.1)

dev.off()


### Generating plots of true positive percentages (barplots)

pdf('efficacy_bars.pdf',10,10)
par(mfrow=c(2,2))

shadesOfGrey<- c("#FFFFFF","#484848","#D9D9D9","#000000")

# Barplot modulation score

bar<-barplot(modul_mean_and_ci$mean,beside=T,ylim=c(0,41),yaxt='n',
             space=c(0.2,0.2,0.2,0.7,0.2,0.2,rep(c(1.5,0.2,0.2,0.7,0.2,0.2),2)),
             col=rep(shadesOfGrey,c(1,2,1,2)), cex.axis = 1.3,cex.names = 1.3,cex.lab=1.3)

bar<-barplot(modul_mean_and_ci$mean,beside=T,yaxt='n',
             space=c(0.2,0.2,0.2,0.7,0.2,0.2,rep(c(1.5,0.2,0.2,0.7,0.2,0.2),2)),
             density=c(0,10,13),angle = 45,col='white',add=T, cex.axis = 1.3,cex.names = 1.3,
             cex.lab=1.3)

bar<-barplot(modul_mean_and_ci$mean,beside=T, 
             ylab='True positive (%)',xlab='Percentile',
             space=c(0.2,0.2,0.2,0.7,0.2,0.2,rep(c(1.5,0.2,0.2,0.7,0.2,0.2),2)),
             density=c(0,0,13),angle = 135,col='white',add=T, cex.axis = 1.3,cex.names = 1.3,
             cex.lab=1.3)


legend(0,40,legend = c(expression(OT[hs]),expression(E[hs]),
                            expression(OT[max]),expression(E[max])),
                            fill=shadesOfGrey,bty = 'n',cex=1.1,
                            title = 'scoring system:')

legend(0,26,legend=c("OT",expression(OT[ext.])),
       fill='black',bty = 'n',cex=1.1,density=13,title = 'association set:')

legend(0,26,legend=c("OT",expression(OT[ext.])),
       fill='black',bty = 'n',cex=1.1,density=13,angle=c(45,135),
       title ='association set:')


segments(bar,modul_mean_and_ci$CI_inf,bar,modul_mean_and_ci$CI_sup,lty=2)
arrows(bar,modul_mean_and_ci$CI_inf,bar,modul_mean_and_ci$CI_sup,angle=90,length= 0.05,code=3,lty=2)

# Barplot tissue specificity score

bar<-barplot(tissue_mean_and_ci$mean,beside=T,ylim=c(0,41),yaxt='n',
             space=c(0.2,0.2,0.2,0.7,0.2,0.2,rep(c(1.5,0.2,0.2,0.7,0.2,0.2),2)),
             col=rep(shadesOfGrey,c(1,2,1,2)), cex.axis = 1.3,cex.names = 1.3,
             cex.lab=1.3)

bar<-barplot(tissue_mean_and_ci$mean,beside=T,yaxt='n',
             space=c(0.2,0.2,0.2,0.7,0.2,0.2,rep(c(1.5,0.2,0.2,0.7,0.2,0.2),2)),
             density=c(0,10,13),angle = 45,col='white',add=T, cex.axis = 1.3,cex.names = 1.3,
             cex.lab=1.3)

bar<-barplot(tissue_mean_and_ci$mean,beside=T, 
             ylab='True positive (%)',xlab='Percentile',
             space=c(0.2,0.2,0.2,0.7,0.2,0.2,rep(c(1.5,0.2,0.2,0.7,0.2,0.2),2)),
             density=c(0,0,13),angle = 135,col='white',add=T, cex.axis = 1.3,cex.names = 1.3,
             cex.lab=1.3)


segments(bar,tissue_mean_and_ci$CI_inf,bar,tissue_mean_and_ci$CI_sup,lty=2)
arrows(bar,tissue_mean_and_ci$CI_inf,bar,tissue_mean_and_ci$CI_sup,angle=90,length= 0.05,code=3,lty=2)

dev.off()


### Generating venn diagram

library(VennDiagram)

venn<-list(open_targets=colnames(opt.score),modulation=names(modul_score),
           tissue_specificity=names(tissue_score))

venn.diagram(venn,filename = 'prova_venn.tiff',fill=c('lightslateblue','turquoise','skyblue3'),
             cat.cex=1.1,cex=1, category.names= c('OT','modulation','tissue-specific'),
             cat.fontfamily='sans',fontfamily='sans',fontface="bold",
             lty=0,height = 1800,width = 1800,
             cat.just=list(c(0,0),c(0.65,0),c(0.5,0.5)))
