setwd('~/Documents')

### Importing safety scores

ADR_score<-read.table('ADR_score.txt',stringsAsFactors=F)
ADR_score<-setNames(ADR_score$V2,ADR_score$V1)

centrality_score<-read.table('centrality_score.txt',stringsAsFactors=F)
centrality_score<-setNames(centrality_score$V2,centrality_score$V1)

onco_score<-read.table('onco_score.txt',stringsAsFactors=F)
onco_score<-setNames(onco_score$V2,onco_score$V1)


### Computing overall safety score

safety_scores<-list(ADR=ADR_score,centrality=centrality_score,onco_driven=onco_score)

all_genes<-Reduce('union',sapply(safety_scores,names))

mat_scores<-matrix(0,nrow=length(all_genes),ncol=length(safety_scores),
                   dimnames=list(all_genes,names(safety_scores)))

for(i in names(safety_scores)){
  mat_scores[names(safety_scores[[i]]),i]<-safety_scores[[i]]
}

library(scales)

safety_scores[['overall']]<-apply(mat_scores,1,function(x)sum(sort(x,decreasing=T)/(c(1:3)^2)))
safety_scores[['overall']]<-rescale(safety_scores[['overall']],to=c(0,1))


### Defining list of golden standards

withdrawn<-unlist(read.table('withdrawn.txt',stringsAsFactors=F),use.names=F)

without_result<-unlist(read.table('clinical_trials_without_result.txt',stringsAsFactors=F),use.names=F)

G.S<-unlist(read.table('G.S.txt',stringsAsFactors=F),use.names=F)

is_cancer<-read.table('is_cancer.txt',sep='\t',header=F)

essential<-read.csv('Homo sapiens_consolidated.csv',stringsAsFactors=F)

gs_split<-matrix(unlist(strsplit(G.S,'-')),byrow=T,ncol=2)

cancer_target<-unique(gs_split[gs_split[,2]%in%is_cancer[,1][is_cancer[,2]=='YES'],1])

true_positive<-setdiff(setdiff(gs_split[,1],cancer_target),withdrawn)

essential<-essential$locus[essential$essentiality.consensus=='Essential']

gs_l<-list(withdrawn,cancer_target,essential,without_result,true_positive)
names(gs_l)<-c('withdrawn_drug targets','cancer targets','essential genes',
               'failed_trial targets','control')


### Assessing true positive rate means and confidence intervals

define_mean_and_ci<-function(gs_l,score,nm){
  
  missing<-setdiff(Reduce('union',gs_l),names(score))
  
  score<-c(score,rep(0,length(missing)))
  names(score)[(length(score)-(length(missing)-1)):length(score)]<-missing
  
  score<-sort(score,decreasing=T)
  
  mat_list<-list()
  perc<-c(1,c(1:2)*5)
  
  set.seed(123)
  
  for(i in 1:100){
    gs_l_boot<-lapply(gs_l,function(x)sample(x,size=round(length(x)*0.8)))
    mat_perc<-matrix(0,nrow=length(gs_l),ncol=3,dimnames=list(names(gs_l),paste(perc,'%',sep='')))  
    
    for(j in 1:nrow(mat_perc)){
      for(k in 1:ncol(mat_perc)){
        score_perc<-score[1:round((length(score)*perc[k])/100)]
        mat_perc[j,k]<-round((sum(names(score_perc)%in%gs_l_boot[[j]])/length(gs_l_boot[[j]]))*100,1)
      }
    }
    mat_list[[i]]<-mat_perc
  }
  
  m<-melt(mat_list)
  m[,1]<-as.character(m[,1])
  m[,2]<-as.character(m[,2])
  
  d<-sapply(unique(m$Var2),function(i)melt(sapply(unique(m$Var1),function(j)
    m$value[m$Var2==i&m$Var1==j],simplify = F)),simplify = F)
  
  d.lm<-lapply(d,function(x)lm(value~L1,data=x))
  d.aov<-lapply(d.lm,aov)
  
  tuckey.test<-lapply(d.aov,TukeyHSD)
  
  mat_mean<-lapply(d,function(x)aggregate(x$value,list(x$L1),mean))
  CI<-lapply(d,function(x)aggregate(x$value,list(x$L1),quantile,probs=c(0.25,0.975)))
  
  
  tuckey.missing<-lapply(tuckey.test,function(x){y<-do.call(rbind,strsplit(rownames(x$L1),'-'));
                                     x$L1[,1:3]<-round(x$L1[,1:3],3);
                                     y<-cbind(y,x$L1);colnames(y)[1:2]<-c('grp1','grp2');y})
  
  tuckey.missing<-mapply(function(x,y)merge(x,y,by.x='grp1',by.y='Group.1'),
                         tuckey.missing,mat_mean,SIMPLIFY=F)
  
  tuckey.missing<-mapply(function(x,y)merge(x,y,by.x='grp2',by.y='Group.1'),
                         tuckey.missing,mat_mean,SIMPLIFY=F)
  
  tuckey.missing<-lapply(tuckey.missing,function(x){x<-x[,c(2:1,7:8,3:6)];
                                        colnames(x)[3:4]<-c('mean1','mean2');x})
  
  for(i in names(d.aov)){
    sink(file=paste('Test/anova_',nm,'_',i,'.txt',sep=''))
    summary(d.aov[[i]])
    sink()
    write.table(tuckey.missing[[i]],file=paste('Test/tuckey_',nm,'_',i,'.txt',sep=''),
                sep='\t',quote=F,row.names =F,col.names =T)
  }
  
  mat_mean<-do.call(cbind,lapply(mat_mean,function(x)setNames(x$x,x$Group.1)))[c(2,5:3,1),]
  
  CI_inf<-do.call(cbind,lapply(CI,function(x)setNames(x$x[,1],x$Group.1)))[c(2,5:3,1),]
  CI_sup<-do.call(cbind,lapply(CI,function(x)setNames(x$x[,2],x$Group.1)))[c(2,5:3,1),]
  
  res<-list(mat_mean,CI_inf,CI_sup)
  names(res)<-c('mean','CI_inf','CI_sup');res 
}

library(reshape2)

mean_and_ci<-sapply(names(safety_scores),function(i)
  define_mean_and_ci(gs_l,safety_scores[[i]],i),simplify = F)


### Assessing positive predictive values

ppvpercents<- function(n,ind) {
  nconn <- n
  ppv <- vector ()
  iters <- seq (1, 100,1)
  for (i in 1:length(iters)){
    perc <- round(nconn/100 * iters[i])
    ppv[[i]]<- sum(ind<perc)/perc/(length(ind)/nconn)
  }
  return(list(x=iters,y=ppv))
}


ind<-lapply(safety_scores,function(x)order(x,decreasing=T))
ppv<-lapply(safety_scores,function(x)names(x)%in%Reduce(union,gs_l[1:4]))

ppvperc<-mapply(function(i,x)ppvpercents(length(i),which(x[i])),ind,ppv,SIMPLIFY=F)


### Generating plots of true positive percentages (barplots)

shadesOfGrey<-colorRampPalette(c("grey100","grey25"))

pdf('safety_bars.pdf',10,10)
par(mfrow=c(2,2))

bar<-barplot(mean_and_ci[[1]]$mean,beside=T,legend=gsub('_','-',rownames(mean_and_ci[[1]]$mean)),
             args.legend=list(x='topleft',bty='n',cex=1.3),ylim=c(0,42),space=c(0.2,1.5),
             ylab='True positive (%)',xlab='Percentile',main='',col=shadesOfGrey(n = 5),
             cex.axis = 1.3,cex.names = 1.3,cex.lab=1.3)

segments(bar,mean_and_ci[[1]]$CI_inf,bar,mean_and_ci[[1]]$CI_sup,lty=2)
arrows(bar,mean_and_ci[[1]]$CI_inf,bar,mean_and_ci[[1]]$CI_sup,angle=90,length= 0.05,code=3,lty=2)

for(i in names(safety_scores)[2:4]){
  bar<-barplot(mean_and_ci[[i]]$mean,beside=T,ylim=c(0,42), space=c(0.2,1.5),
               ylab='True positive (%)',xlab='Percentile',main='',col=shadesOfGrey(n = 5),
               cex.axis = 1.3,cex.names = 1.3,cex.lab=1.3)
  
  segments(bar,mean_and_ci[[i]]$CI_inf,bar,mean_and_ci[[i]]$CI_sup,lty=2)
  arrows(bar,mean_and_ci[[i]]$CI_inf,bar,mean_and_ci[[i]]$CI_sup,angle=90,length= 0.05,code=3,lty=2)
}

dev.off()


### Generating plot of positive predictive values (lineplots)

pdf('safety_ppvs.pdf',5,5)

library(RColorBrewer)

col_pal=brewer.pal(4,'Dark2')

plot(ppvperc[[1]]$x,ppvperc[[1]]$y,type='l',col=col_pal[[1]],xlab='Percentile(%)',ylab='Normalized PPV',
     ylim=c(0,6),lwd=3,xlim=c(0,50),panel.first=abline(h=1:6,v=seq(0,50,by=5),lwd=2,lty=3,col="lightgray"),
     cex=1.1)
for(i in 2:length(ppvperc)){
  lines(ppvperc[[i]]$x,ppvperc[[i]]$y,type='l',col=col_pal[i],lwd=3,lty=c(rep(1,6),2,2)[i])
}
abline(1,0,col='black',lty=2,lwd=2)
legend('topright',fill = col_pal,legend =c('ADR','centrality','onco-driven','overall'),bty = 'n',cex = 1.1)

dev.off()


### Generating venn diagram

library(VennDiagram)

venn.diagram(x=lapply(safety_scores[1:3],names),filename = 'safety_venn.tiff',
             fill=c('lightsalmon1','pink1','mediumorchid'),cat.cex=1.1,cex=1,
             category.names= c('ADR','centrality','onco-driven'),cat.fontfamily='sans',
             fontfamily='sans',fontface='bold',lty=0,height = 1800,width = 1800,
             cat.just=list(c(0,0),c(0.6,0),c(0.5,0.5)))

